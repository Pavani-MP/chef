The following command opens a socks connection with the master instance in a cluster with the cluster ID ``j-3SD91U2E1L2QX``::

  aws emr socks --cluster-id j-3SD91U2E1L2QX --key-pair-file ~/.ssh/mykey.pem

The key pair file option takes a local path to a private key file.