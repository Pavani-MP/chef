The following command adds a 5 day retention policy to a log group named ``my-logs``::

  aws logs put-retention-policy --log-group-name my-logs --retention-in-days 5
