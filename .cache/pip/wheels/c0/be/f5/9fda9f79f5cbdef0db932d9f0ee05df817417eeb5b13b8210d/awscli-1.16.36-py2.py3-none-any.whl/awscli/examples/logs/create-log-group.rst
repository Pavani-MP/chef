The following command creates a log group named ``my-logs``::

  aws logs create-log-group --log-group-name my-logs
